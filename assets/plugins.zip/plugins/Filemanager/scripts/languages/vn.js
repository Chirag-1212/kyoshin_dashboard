{
    "ALLOWED_FILE_TYPE": "Only following files are allowed : ", 
    "AUTHORIZATION_REQUIRED": "Bạn không có quyền sử dụng filemanager.", 
    "DIRECTORY_ALREADY_EXISTS": "Đã có thư mục '%s'.", 
    "DIRECTORY_NOT_EXIST": "Không thấy thư mục %s.", 
    "DISALLOWED_FILE_TYPE": "Following files are not allowed : ", 
    "ERROR_RENAMING_DIRECTORY": "Có lỗi khi đổi tên thư mục %s thành %s.", 
    "ERROR_RENAMING_FILE": "Có lỗi khi đổi tên tập tin %s thành %s.", 
    "FILE_ALREADY_EXISTS": "Đã có tập tin '%s'.", 
    "FILE_DOES_NOT_EXIST": "Không tìm thấy tập tin %s.", 
    "INVALID_ACTION": "Thao tác không hợp lệ.", 
    "INVALID_DIRECTORY_OR_FILE": "Thư mục hoặc tập tin không hợp lệ.", 
    "INVALID_FILE_TYPE": "File upload is not allowed.", 
    "INVALID_FILE_UPLOAD": "Tập tin tải lên không hợp lệ.", 
    "INVALID_VAR": "var không hợp lệ %s.", 
    "LANGUAGE_FILE_NOT_FOUND": "Không thấy tập tin ngôn ngữ.", 
    "MODE_ERROR": "Lỗi chế độ.", 
    "UNABLE_TO_CREATE_DIRECTORY": "Không thể tạo thư mục %s.", 
    "UNABLE_TO_OPEN_DIRECTORY": "Không thể mở thư mục %s.", 
    "UPLOAD_FILES_SMALLER_THAN": "Chỉ tải được tập tin có kích thước nhỏ hơn %s.", 
    "UPLOAD_IMAGES_ONLY": "Chỉ tải hình ảnh, các loại tập tin khác không tải được.", 
    "UPLOAD_IMAGES_TYPE_JPEG_GIF_PNG": "Chỉ tải được các loại hình ảnh sau: JPEG, GIF or PNG.", 
    "browse": "Browse...", 
    "bytes": " bytes", 
    "cancel": "Hủy bỏ", 
    "confirmation_delete": "Bạn chắc chắn muốn xóa tập tin này?", 
    "could_not_retrieve_folder": "Không lấy được nội dung thư mục.", 
    "create_folder": "Tạo thư mục", 
    "created": "Đã tạo", 
    "current_folder": "Thư mục hiện tại: ", 
    "default_foldername": "Thư mục chính", 
    "del": "Xóa", 
    "dimensions": "Kích thước", 
    "download": "Tải xuống", 
    "fck_select_integration": "Chức năng 'Chọn' chỉ dùng với CKEditor.", 
    "file_size_limit": "The file size limit is : ", 
    "file_too_big": "The file is too big.", 
    "gb": "gb", 
    "grid_view": "Chuyển sang chế độ khung lưới.", 
    "kb": "kb", 
    "list_view": "Chuyển sang chế độ liệt kê.", 
    "loading_data": "Transferring data ...", 
    "mb": "mb", 
    "modified": "Đã sửa", 
    "name": "Tên", 
    "new_filename": "Nhập tên tập tin mới", 
    "new_folder": "Thư mục mới", 
    "no": "Không", 
    "no_foldername": "Chưa có tên thư mục.", 
    "parentfolder": "Thư mục cha", 
    "prompt_foldername": "Nhập tên thư mục mới", 
    "rename": "Đổi tên", 
    "search": "Search", 
    "search_reset": "Reset", 
    "select": "Chọn", 
    "select_from_left": "Chọn một mục phía bên trái.", 
    "size": "Kích cỡ", 
    "successful_added_file": "Đã thêm tập tin.", 
    "successful_added_folder": "Đã thêm thư mục.", 
    "successful_delete": "Đã xóa.", 
    "successful_rename": "Đã đổi tên.", 
    "upload": "Tải lên", 
    "yes": "Đồng ý"
}