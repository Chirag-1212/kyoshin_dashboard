{
    "ALLOWED_FILE_TYPE": "Only following files are allowed : ", 
    "AUTHORIZATION_REQUIRED": "Az Ön számára nincsen engedélyezve a fájlkezelő használata.", 
    "DIRECTORY_ALREADY_EXISTS": "A megadott '%s' mappa már létezik.", 
    "DIRECTORY_NOT_EXIST": "A(z) %s mappa nem létezik.", 
    "DISALLOWED_FILE_TYPE": "Following files are not allowed : ", 
    "ERROR_RENAMING_DIRECTORY": "A(z) %s mappa átnevezése %s névre sikertelen volt.", 
    "ERROR_RENAMING_FILE": "A(z) %s fájl átnevezése %s fájlnévre sikertelen volt.", 
    "FILE_ALREADY_EXISTS": "a megadott '%s' fájl már létezik.", 
    "FILE_DOES_NOT_EXIST": "A %s fájl nem található.", 
    "INVALID_ACTION": "Érvénytelen művelet.", 
    "INVALID_DIRECTORY_OR_FILE": "Érvénytelen könyvtár vagy fájlnév.", 
    "INVALID_FILE_TYPE": "File upload is not allowed.", 
    "INVALID_FILE_UPLOAD": "Hibás fájl feltöltés.", 
    "INVALID_VAR": "Érvénytelen var %s.", 
    "LANGUAGE_FILE_NOT_FOUND": "A megadott fordítás nem található.", 
    "MODE_ERROR": "Eljárás hiba.", 
    "UNABLE_TO_CREATE_DIRECTORY": "A(z) %s mappát nem lehet létrehozni.", 
    "UNABLE_TO_OPEN_DIRECTORY": "Nem lehet a(z) %s mappát megnyitni.", 
    "UPLOAD_FILES_SMALLER_THAN": "Kérem csak %s méretnél kisebb fájlokat töltsön fel.", 
    "UPLOAD_IMAGES_ONLY": "Kérem kizárólag képetek töltsön fel, egyéb formátumok nincsenek támogatva.", 
    "UPLOAD_IMAGES_TYPE_JPEG_GIF_PNG": "Kérem kizárólag JPEG, GIF vagy PNG képeket töltsön fel", 
    "browse": "Browse...", 
    "bytes": " byte", 
    "cancel": "Mégse", 
    "confirmation_delete": "Biztosan törölni szeretné a kijelölt fájlt?", 
    "could_not_retrieve_folder": "A mappa tartalmát nem lehet megjeleníteni.", 
    "create_folder": "Új mappa", 
    "created": "Létrehozva", 
    "current_folder": "Jelenlegi mappa: ", 
    "default_foldername": "Saját mappa", 
    "del": "Törlés", 
    "dimensions": "Méretek", 
    "download": "Letöltés", 
    "fck_select_integration": "A 'Kiválasztás' funkció kizárólag FCKEditor használata mellett elérhető.", 
    "file_size_limit": "The file size limit is : ", 
    "file_too_big": "The file is too big.", 
    "gb": "gb", 
    "grid_view": "Váltás dia nézetre.", 
    "kb": "kb", 
    "list_view": "Váltás részletes nézetre.", 
    "loading_data": "Transferring data ...", 
    "mb": "mb", 
    "modified": "Módosítva", 
    "name": "Név", 
    "new_filename": "Adja meg a fájl új nevét", 
    "new_folder": "Új mappa", 
    "no": "Nem", 
    "no_foldername": "Nem adott nevet a mappának.", 
    "parentfolder": "Előző mappa", 
    "prompt_foldername": "Kérem adja meg az új mappa nevét", 
    "rename": "Átnevezés", 
    "search": "Search", 
    "search_reset": "Reset", 
    "select": "Kiválasztás", 
    "select_from_left": "Válasszon egy elemet a bal oldalrol.", 
    "size": "Méret", 
    "successful_added_file": "Az új fájl sikeresen létre lett hozva.", 
    "successful_added_folder": "Az új mappa sikeresen létre lett hozva.", 
    "successful_delete": "Sikeres törlés.", 
    "successful_rename": "Sikeres átnevezés.", 
    "upload": "Feltöltés", 
    "yes": "Igen"
}